<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for SpookyApp.

3.0.0-pl
==============
- Requires MODX 3.
- Requires PHP 7.2+.
- Refactored to use PSR-4 autoload.

2.0.0-pl
==============
- New build script.
- [#4] Ability to specify the exact repository to install package from.
- [#6] Renaming script works in any environment.
- Updated tables resolver.
- All tables now InnoDB by default.
- Removed shell renaming script.

1.0.1-beta
==============
- PSR-2
- Requires at least MODX 2.3
- Disabling "office" resolver will clear its files from built package.
- Fixed some typos.

1.0.0-beta
==============
- Optimized for MODX 2.3
- Improved processors
- Disabled plugin and system settings
- Improved UI
- Added grid actions
- Added icons in menu
- Added search in grid
- Grid sorting
- Enable and disable actions',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
SpookyApp
--------------------
Author: Stanislav R <spookyr31>
--------------------
Дополнение (Extra) для MODX Revolution 3.x. (основано на ModExtra3 https://github.com/modx-pro/ModExtra3). Компонент агрегирует и отображает контент из внешних источников: фильмы, сериалы, персоны, игры, устройства, товары, спортивные данные. Данные приходят через внешние API (TMDB, RAWG, спортивные API и др.), нормализуются и кешируются в собственных таблицах MySQL для ускорения работы и снижения количества запросов к сторонним сервисам.

Данные получаются через внешние API (TMDB, RAWG, спортивные API и др.), нормализуются и кешируются в собственных таблицах MySQL для ускорения работы и снижения количества запросов к сторонним сервисам.

Дополнительно используется Yandex Cloud (AI Studio / SpeechKit / Translate) для:

* перевода данных
* рерайта текстов
* генерации озвучки


Я **не несу ответственности** за:

* точность данных
* актуальность
* доступность API
* изменения в форматах ответов
* юридический статус контента

Причина выбора внешних API:

* высокая скорость получения данных
* отсутствие необходимости ручного наполнения
* широкий охват тематик (кино, игры, спорт, новости)
* наличие структурированных данных

Yandex Cloud используется в первую очередь для:

* перевода (включая массовую обработку полей)
* рерайта текстов
* озвучки через SpeechKit

Выбор сделан на основе практического опыта, ранее использовался SpeechKit для озвучивания контента (в других проектах, в частности озвучки расписания на сайте кинотеатра), качество синтеза речи оказалось достаточным для продакшена, удобная интеграция через API

## История и идея проекта

Основная идея компонента появилась из практической задачи:
При разработке  панели администратора для контента для кинотеатра использовались внешние API и SpeechKit для озвучивания. Мне понравился такой подход и к тому же часто при написании статей для блога хочется получать некую точную информацию, которую постоянно выдергивать с postman иногда неудобно и хотелось все иметь в рамках одной админки modx. Сейчас развитие AI-инструментов (в том числе интеграция в Visual Studio Code через GitHub Copilot и аналогичные решения) позволило значительно упростить разработку и масштабировать эту идею. 

В данном случае используются следующие API (большая часть из RapidAPI) и доступ к ним задается из системных настроек MODX:

```
spookyapp.yandex_api_key        — Yandex Cloud API key (GPT, Translate, SpeechKit)
spookyapp.yandex_folder_id      — Yandex Cloud Folder ID
spookyapp.tmdb_bearer_token     — TMDB Bearer Token
spookyapp.rawg_api_key          — RAWG (игры)
spookyapp.rapidapi_key          — общий RapidAPI key
spookyapp.mobileapi_token       — MobileApi.dev token
spookyapp.football_api_key      — api-football (RapidAPI)
spookyapp.flashlive_api_key     — FlashLive Sports (RapidAPI)
spookyapp.sportapi7_api_key     — SportAPI7 (RapidAPI)
spookyapp.reddit34_rapidapi_key — Reddit34 (RapidAPI)
spookyapp.github_token          — GitHub PAT (опционально, лимит без него ~60 req/h)
spookyapp.thenewsapi_key        — TheNewsAPI
spookyapp.newsdata_key          — NewsData.io
```

## Ограничения

* Компонент находится в стадии активной разработки
* Возможны ошибки, нестабильная работа и несовместимости
* Развертывание может быть нетривиальным (ориентирован на опытных пользователей MODX)
* Некоторые части требуют ручной доработки под конкретный проект

Этот компонент публикуется в первую очередь как:

* рабочий инструмент
* экспериментальная база
* личный проект
* оставить хоть что-то в разработке под modx

Он **не ориентирован на массовое использование "из коробки"**. 

Если вы планируете использовать его в продакшене — потребуется:

* понимание архитектуры MODX
* навыки работы с API
* готовность адаптировать код под себя',
    'requires' => 
    array (
      'php' => '>=7.2.0',
      'modx' => '>=3.0.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '040818cde6b36ae514c868be06ec0545',
      'native_key' => 'spookyapp',
      'filename' => 'MODX/Revolution/modNamespace/9a36db8996f9c40dcc7a9115975b866b.vehicle',
      'namespace' => 'spookyapp',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'b0937722de1775fd1ccad35fbe44bdca',
      'native_key' => 'spookyapp',
      'filename' => 'MODX/Revolution/modMenu/90eb457e633ae10c0deb438a40708624.vehicle',
      'namespace' => 'spookyapp',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b018e632aed2e7b9623b4ae70616c9fe',
      'native_key' => 'spookyapp.blog_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/aa4a3b09e21780ce014266252fbd6c50.vehicle',
      'namespace' => 'spookyapp',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5affa9d7ca237fac950d3544de99343f',
      'native_key' => 'spookyapp.yandex_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/f166ebfaf22aa9116d29ad96e36e0c95.vehicle',
      'namespace' => 'spookyapp',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3d8082af7fa9e19a07a2722ac8844352',
      'native_key' => 'spookyapp.yandex_folder_id',
      'filename' => 'MODX/Revolution/modSystemSetting/1b27f44d171d9d7562fec2e9406b6673.vehicle',
      'namespace' => 'spookyapp',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e88dc4cead3e28483d30c033ee02d564',
      'native_key' => 'spookyapp.tmdb_bearer_token',
      'filename' => 'MODX/Revolution/modSystemSetting/a17d8fe876891e892a5affcf7e0331db.vehicle',
      'namespace' => 'spookyapp',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ee413a8defcaf87392afa3243248fdc',
      'native_key' => 'spookyapp.rawg_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/939530588f11a5abff42a8fbdb55f5d3.vehicle',
      'namespace' => 'spookyapp',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9999acad0ec0bc2e8ae62e1a1eebdff1',
      'native_key' => 'spookyapp.rapidapi_key',
      'filename' => 'MODX/Revolution/modSystemSetting/755ae1b2a58dd3f5c0d8680354e6452b.vehicle',
      'namespace' => 'spookyapp',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f3a21a2c7c5b110b2fbca90fa47f374a',
      'native_key' => 'spookyapp.mobileapi_token',
      'filename' => 'MODX/Revolution/modSystemSetting/989c2d55c157598a6ab4a39f1b88c83e.vehicle',
      'namespace' => 'spookyapp',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '286c75109f8f0ad4368d0ff82599bc71',
      'native_key' => 'spookyapp.github_token',
      'filename' => 'MODX/Revolution/modSystemSetting/3d3089cce07e6b753adcc22da7732152.vehicle',
      'namespace' => 'spookyapp',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f5eccaaa8a764fdc1318bed163be11a4',
      'native_key' => 'spookyapp.reddit34_rapidapi_key',
      'filename' => 'MODX/Revolution/modSystemSetting/6a351b214177359f5ad5aac69dc3e8f1.vehicle',
      'namespace' => 'spookyapp',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '626b940351511ba8156ac198f53fc9d8',
      'native_key' => 'spookyapp.thenewsapi_key',
      'filename' => 'MODX/Revolution/modSystemSetting/d085166fcd8abe271479d3fb41d17e41.vehicle',
      'namespace' => 'spookyapp',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9ae249b5b6bdc55fd816654ff6cce40a',
      'native_key' => 'spookyapp.newsdata_key',
      'filename' => 'MODX/Revolution/modSystemSetting/d0fabe1301a275b64be992d53071775b.vehicle',
      'namespace' => 'spookyapp',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6f48b8d6f51dc8d40d44298631348c9e',
      'native_key' => 'spookyapp.football_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/2476863098734a22cdb0ce0cafbd8596.vehicle',
      'namespace' => 'spookyapp',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b482171f0a7e3206edf0abf855a995f1',
      'native_key' => 'spookyapp.flashlive_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/17ef05ed3b05494aa889c2a65b14c675.vehicle',
      'namespace' => 'spookyapp',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '371946a0962369c04f76218d6a4a960c',
      'native_key' => 'spookyapp.sportapi7_api_key',
      'filename' => 'MODX/Revolution/modSystemSetting/aa80834d764f51a359a88b535acc1a22.vehicle',
      'namespace' => 'spookyapp',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '0cd3829e1fd3d15bf3ca75b41a93330e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/fd0f99fbff40e2535ab7c3bd371a0d89.vehicle',
      'namespace' => 'spookyapp',
    ),
  ),
);