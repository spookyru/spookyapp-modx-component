<?php

use MODX\Revolution\modExtraManagerController;

/**
 * The home manager controller for SpookyApp.
 *
 */
class SpookyAppHomeManagerController extends modExtraManagerController
{
    /** @var SpookyApp\SpookyApp $SpookyApp */
    public $SpookyApp;


    /**
     *
     */
    public function initialize()
    {
        $this->SpookyApp = $this->modx->services->get('SpookyApp');
        parent::initialize();
    }


    /**
     * @return array
     */
    public function getLanguageTopics()
    {
        return ['spookyapp:default'];
    }


    /**
     * @return bool
     */
    public function checkPermissions()
    {
        return true;
    }


    /**
     * @return null|string
     */
    public function getPageTitle()
    {
        return $this->modx->lexicon('spookyapp');
    }


    /**
     * @return void
     */
    public function loadCustomCssJs()
    {
        $this->addCss($this->SpookyApp->config['cssUrl'] . 'mgr/main.css');
        $this->addJavascript($this->SpookyApp->config['jsUrl'] . 'mgr/spookyapp.js');
        $this->addJavascript($this->SpookyApp->config['jsUrl'] . 'mgr/misc/utils.js');
        $this->addJavascript($this->SpookyApp->config['jsUrl'] . 'mgr/misc/combo.js');
        $this->addJavascript($this->SpookyApp->config['jsUrl'] . 'mgr/widgets/items.grid.js');
        $this->addJavascript($this->SpookyApp->config['jsUrl'] . 'mgr/widgets/items.windows.js');
        $this->addJavascript($this->SpookyApp->config['jsUrl'] . 'mgr/widgets/home.panel.js');
        $this->addJavascript($this->SpookyApp->config['jsUrl'] . 'mgr/sections/home.js');

        $this->addHtml('<script type="text/javascript">
        SpookyApp.config = ' . json_encode($this->SpookyApp->config) . ';
        SpookyApp.config.connector_url = "' . $this->SpookyApp->config['connectorUrl'] . '";
        Ext.onReady(function() {MODx.load({ xtype: "spookyapp-page-home"});});
        </script>');
    }


    /**
     * @return string
     */
    public function getTemplateFile()
    {
        $this->content .= '<div id="spookyapp-panel-home-div"></div>';
        return '';
    }
}
